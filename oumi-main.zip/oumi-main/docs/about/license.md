# License

This project is licensed under the Apache License 2.0, which allows for broad use, modification, and distribution within the open source community.

The full license terms and conditions can be found below.

## Apache License 2.0

```{include} ../../LICENSE
```
