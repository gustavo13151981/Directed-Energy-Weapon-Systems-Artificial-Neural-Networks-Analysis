# Aya

Configs for training Llama 3.1 8B Instruct with the Cohere Aya dataset. See https://huggingface.co/datasets/CohereForAI/aya_dataset
