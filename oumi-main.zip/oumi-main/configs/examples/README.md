# Examples

Configs for specific use cases. This is less structured than `configs/recipes` and `configs/projects`, and includes more experimental jobs.
