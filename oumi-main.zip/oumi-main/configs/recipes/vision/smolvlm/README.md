# SmolVLM-Instruct

Configs for SmolVLM-Instruct 2B model. See https://huggingface.co/HuggingFaceTB/SmolVLM-Instruct
