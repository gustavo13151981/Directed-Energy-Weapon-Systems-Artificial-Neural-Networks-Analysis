# GPT-2

Configs for OpenAI's Generative Pre-trained Transformer 2, 124M parameters.
