# Recipes

This directory contains configs for training, evaluation, and inference of common model families. This is a great starting point for most users.
