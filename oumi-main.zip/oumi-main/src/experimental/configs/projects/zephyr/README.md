# Zephyr

Configs for training HuggingFace's Zephyr model: a Mistral 7B model trained on a filtered version of UltraChat 200k.

Dataset: https://huggingface.co/datasets/HuggingFaceH4/ultrachat_200k
Model: https://huggingface.co/mistralai/Mistral-7B-v0.1
