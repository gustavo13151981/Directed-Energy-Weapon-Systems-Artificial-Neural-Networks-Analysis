package com.ews.util;

public interface IHasModel 
{

	public void registerModels();
	
}
