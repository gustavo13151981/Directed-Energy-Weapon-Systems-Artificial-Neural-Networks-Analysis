package com.ews.items.EnergyItems;

import com.ews.Main;
import com.ews.init.ModItems;

public class RubyEnergyTablet extends EnergyContainerItem{

    public RubyEnergyTablet(String name, int capacity) {
        super(name, capacity);
        
        setUnlocalizedName(name);
        setRegistryName(name);
        setCreativeTab(Main.EWS_TAB);
        
        ModItems.ITEMS.add(this);
    }
        
        
        
        @Override
        public void registerModels(){
            
        Main.proxy.registerItemRenderer(this, 0, "inventory");
        }
    

}



// I'm giving u access to it on Curse for this help XDDDD (when i figure out how to...)